import { useState } from 'react';
import { Filter } from 'lucide-react';

// ── Mock data ─────────────────────────────────────────────────────────────────

const campaigns = [
  `Все кампании`,
  `Летний кэшбэк`,
  `Back to School`,
  `Авто сезон`,
  `Ресторанный март`,
];

const periods = [`7 дней`, `14 дней`, `30 дней`, `90 дней`];
const channels = [`Все каналы`, `Push`, `Email`, `SMS`];
const segmentFilters = [`Все сегменты`, `Premium`, `Mass`, `VIP`, `Новые`, `Спящие`];

interface FunnelStep {
  label: string;
  value: number;
}

const funnelBase: FunnelStep[] = [
  { label: `Целевая аудитория`, value: 840000 },
  { label: `Получили предложение`, value: 612000 },
  { label: `Открыли`, value: 298000 },
  { label: `Приняли`, value: 134000 },
  { label: `Совершили транзакцию`, value: 89000 },
  { label: `Получили кэшбэк`, value: 82000 },
];

const segments = [`Premium`, `Mass`, `VIP`, `Новые`, `Спящие`];
const mccCats = [`Рестораны`, `Супермаркеты`, `АЗС`, `Аптеки`, `Одежда`, `Электроника`, `Транспорт`, `Развлечения`];

// Fixed heatmap data for matrix
const matrixData: number[][] = [
  [4.2, 3.8, 2.1, 1.5, 3.3, 4.7, 2.9, 1.8],
  [2.8, 4.5, 3.9, 2.2, 1.7, 2.4, 3.1, 4.0],
  [5.1, 4.8, 3.2, 4.1, 5.0, 3.7, 2.5, 3.6],
  [1.9, 3.0, 2.6, 1.3, 2.8, 1.6, 4.2, 3.4],
  [3.3, 1.8, 4.4, 3.7, 1.2, 3.0, 2.1, 1.9],
];

function matrixHeatLevel(v: number): string {
  if (v < 1.5) return `heat-cell-0`;
  if (v < 2.5) return `heat-cell-1`;
  if (v < 3.2) return `heat-cell-2`;
  if (v < 3.9) return `heat-cell-3`;
  if (v < 4.5) return `heat-cell-4`;
  return `heat-cell-5`;
}

function fmtK(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(2)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(0)}K`;
  return String(n);
}

// ── Funnel Component ──────────────────────────────────────────────────────────

function FunnelChart({ data }: { data: FunnelStep[] }) {
  const max = data[0].value;
  const colors = [
    `var(--primary)`,
    `#6366f1`,
    `#818cf8`,
    `#06b6d4`,
    `#10b981`,
    `#34d399`,
  ];

  return (
    <div className="flex flex-col gap-3">
      {data.map((step, i) => {
        const pct = Math.round((step.value / max) * 100);
        const conv = i > 0 ? Math.round((step.value / data[i - 1].value) * 100) : null;
        return (
          <div key={step.label} className="flex flex-col gap-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-foreground">{step.label}</span>
              <div className="flex items-center gap-3">
                {conv !== null && (
                  <span
                    className="px-2 py-0.5 rounded-full text-xs font-semibold"
                    style={{ background: `${colors[i]}20`, color: colors[i] }}
                  >
                    ↓ {conv}%
                  </span>
                )}
                <span className="text-muted-foreground w-16 text-right">{fmtK(step.value)}</span>
              </div>
            </div>
            <div className="relative h-8 bg-muted rounded-r-md overflow-hidden">
              <div
                className="h-full rounded-r-md transition-all duration-700"
                style={{ width: `${pct}%`, background: colors[i] }}
              />
              <span
                className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold"
                style={{ color: pct > 20 ? `#fff` : colors[i] }}
              >
                {pct}%
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

export default function Analytics() {
  const [campaign, setCampaign] = useState(`Все кампании`);
  const [period, setPeriod] = useState(`30 дней`);
  const [channel, setChannel] = useState(`Все каналы`);
  const [segment, setSegment] = useState(`Все сегменты`);

  // Slightly vary funnel data by selection for demo
  const funnelData: FunnelStep[] = funnelBase.map((s, i) => ({
    ...s,
    value: Math.round(s.value * (campaign === `Все кампании` ? 1 : 0.7 + Math.random() * 0.3)),
  }));

  return (
    <div data-cmp="Analytics" className="p-8 flex flex-col gap-6">

      {/* Filters */}
      <div className="bg-card rounded-xl border border-border p-4 flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
          <Filter size={15} />
          Фильтры:
        </div>
        {[
          { label: `Кампания`, value: campaign, opts: campaigns, set: setCampaign },
          { label: `Период`, value: period, opts: periods, set: setPeriod },
          { label: `Канал`, value: channel, opts: channels, set: setChannel },
          { label: `Сегмент`, value: segment, opts: segmentFilters, set: setSegment },
        ].map(({ label, value, opts, set }) => (
          <div key={label} className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">{label}:</span>
            <select
              value={value}
              onChange={(e) => set(e.target.value)}
              className="px-3 py-1.5 text-sm border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-ring"
            >
              {opts.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
        ))}
      </div>

      {/* Main content */}
      <div className="flex gap-5">

        {/* Funnel */}
        <div className="flex-1 bg-card rounded-xl border border-border p-6 shadow-custom">
          <div className="mb-5">
            <h2 className="text-sm font-semibold text-foreground">Воронка кэшбэк-предложения</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Убывание аудитории по этапам · {period} · {campaign}
            </p>
          </div>
          <FunnelChart data={funnelData} />

          {/* Summary row */}
          <div className="flex gap-4 mt-6 pt-5 border-t border-border">
            <div className="flex-1 text-center">
              <p className="text-xs text-muted-foreground mb-1">Общая конверсия</p>
              <p className="text-2xl font-extrabold" style={{ color: `var(--primary)` }}>
                {((funnelData[5].value / funnelData[0].value) * 100).toFixed(1)}%
              </p>
            </div>
            <div className="flex-1 text-center">
              <p className="text-xs text-muted-foreground mb-1">Получили кэшбэк</p>
              <p className="text-2xl font-extrabold text-foreground">{fmtK(funnelData[5].value)}</p>
            </div>
            <div className="flex-1 text-center">
              <p className="text-xs text-muted-foreground mb-1">Отклик (принятие)</p>
              <p className="text-2xl font-extrabold" style={{ color: `#10b981` }}>
                {((funnelData[3].value / funnelData[1].value) * 100).toFixed(1)}%
              </p>
            </div>
          </div>
        </div>

        {/* Segment × Category matrix */}
        <div className="bg-card rounded-xl border border-border p-6 shadow-custom" style={{ minWidth: 520 }}>
          <div className="mb-5">
            <h2 className="text-sm font-semibold text-foreground">Матрица: Сегмент × Категория MCC</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Тепловая карта показателей отклика (%)</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr>
                  <th className="text-left pb-3 pr-3 text-muted-foreground font-normal" style={{ width: 80 }}>Сегмент</th>
                  {mccCats.map((cat) => (
                    <th
                      key={cat}
                      className="pb-3 px-1 text-center font-normal text-muted-foreground"
                      style={{ writingMode: `vertical-rl`, transform: `rotate(180deg)`, height: 72, fontSize: 11 }}
                    >
                      {cat}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {segments.map((seg, si) => (
                  <tr key={seg}>
                    <td className="py-1 pr-3 font-semibold text-foreground text-xs">{seg}</td>
                    {mccCats.map((_, ci) => {
                      const val = matrixData[si][ci];
                      return (
                        <td key={ci} className="py-1 px-1">
                          <div
                            className={`${matrixHeatLevel(val)} rounded`}
                            style={{
                              width: 44,
                              height: 28,
                              display: `flex`,
                              alignItems: `center`,
                              justifyContent: `center`,
                              fontSize: 11,
                              fontWeight: 700,
                              margin: `0 auto`,
                            }}
                          >
                            {val.toFixed(1)}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Matrix legend */}
          <div className="flex items-center gap-2 mt-4 pt-3 border-t border-border">
            <span className="text-xs text-muted-foreground">Низкий отклик</span>
            {[0, 1, 2, 3, 4, 5].map((v) => (
              <div key={v} className={`heat-cell-${v} rounded`} style={{ width: 22, height: 22 }} />
            ))}
            <span className="text-xs text-muted-foreground">Высокий отклик</span>
          </div>

          {/* Top combos */}
          <div className="mt-4 pt-3 border-t border-border">
            <p className="text-xs font-semibold text-foreground mb-2">Лучшие комбинации</p>
            <div className="flex flex-col gap-1.5">
              {[
                { seg: `VIP`, cat: `Рестораны`, val: 5.1 },
                { seg: `VIP`, cat: `Одежда`, val: 5.0 },
                { seg: `Premium`, cat: `Электроника`, val: 4.7 },
              ].map((row) => (
                <div key={`${row.seg}-${row.cat}`} className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">{row.seg} × {row.cat}</span>
                  <span
                    className="px-2 py-0.5 rounded-full text-xs font-bold"
                    style={{ background: `#4f46e520`, color: `#4f46e5` }}
                  >
                    {row.val.toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
