import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import KpiCard from '../components/KpiCard';

// ── Mock data ──────────────────────────────────────────────────────────────────

const lineData = Array.from({ length: 30 }, (_, i) => ({
  day: `${i + 1}`,
  premium: Math.round(120 + Math.sin(i / 3) * 40 + Math.random() * 20),
  mass: Math.round(80 + Math.cos(i / 4) * 30 + Math.random() * 15),
  vip: Math.round(40 + Math.sin(i / 5) * 20 + Math.random() * 10),
}));

const mccCategories = [
  `Рестораны`, `Супермаркеты`, `АЗС`, `Аптеки`, `Одежда`,
  `Электроника`, `Транспорт`, `Развлечения`, `Спорт`, `Путешествия`,
];
const segments = [`Premium`, `Mass`, `VIP`, `Новые`, `Спящие`];
const heatData: number[][] = segments.map(() =>
  mccCategories.map(() => Math.floor(Math.random() * 6))
);

const topCampaigns = [
  { name: `Летний кэшбэк`, roi: 312, budget: `₽2.4M`, ctr: `8.7%`, status: `active` },
  { name: `Back to School`, roi: 278, budget: `₽1.8M`, ctr: `7.2%`, status: `active` },
  { name: `Авто сезон`, roi: 241, budget: `₽3.1M`, ctr: `6.9%`, status: `paused` },
  { name: `Ресторанный март`, roi: 198, budget: `₽0.9M`, ctr: `5.4%`, status: `active` },
  { name: `Аптека & здоровье`, roi: 175, budget: `₽1.2M`, ctr: `4.8%`, status: `active` },
];

const statusColor: Record<string, string> = {
  active: `#10b981`,
  paused: `#f59e0b`,
};

export default function Dashboard() {
  return (
    <div data-cmp="Dashboard" className="flex flex-col gap-6 p-8">

      {/* KPI Cards */}
      <div className="flex gap-5">
        <div className="flex-1">
          <KpiCard
            title={`Активные кампании`}
            value={`24`}
            subValue={`из 31`}
            delta={12}
            deltaLabel={`vs прошлый месяц`}
            accent={`var(--primary)`}
          />
        </div>
        <div className="flex-1">
          <KpiCard
            title={`Охват аудитории`}
            value={`1.84M`}
            subValue={`уникальных`}
            delta={8.3}
            deltaLabel={`vs прошлый месяц`}
            accent={`#06b6d4`}
          />
        </div>
        <div className="flex-1">
          <KpiCard
            title={`Израсходован. бюджет`}
            value={`₽12.7M`}
            subValue={`из ₽18M`}
            delta={-3.1}
            deltaLabel={`vs план`}
            accent={`#f59e0b`}
          />
        </div>
        <div className="flex-1">
          <KpiCard
            title={`Средний CTR`}
            value={`6.42%`}
            delta={1.8}
            deltaLabel={`vs прошлый месяц`}
            accent={`#10b981`}
          />
        </div>
      </div>

      {/* Line Chart + Heatmap row */}
      <div className="flex gap-5">

        {/* Line chart */}
        <div className="flex-1 bg-card rounded-xl p-6 shadow-custom border border-border" style={{ minWidth: 0 }}>
          <div className="mb-4">
            <h2 className="text-sm font-semibold text-foreground">Динамика принятых предложений — 30 дней</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Разбивка по сегментам клиентов</p>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={lineData} margin={{ top: 4, right: 16, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis
                dataKey="day"
                tick={{ fontSize: 11, fill: `var(--muted-foreground)` }}
                tickLine={false}
                axisLine={false}
                interval={4}
              />
              <YAxis
                tick={{ fontSize: 11, fill: `var(--muted-foreground)` }}
                tickLine={false}
                axisLine={false}
                width={36}
              />
              <Tooltip
                contentStyle={{
                  background: `var(--card)`,
                  border: `1px solid var(--border)`,
                  borderRadius: 8,
                  fontSize: 12,
                }}
                cursor={{ stroke: `var(--border)`, strokeWidth: 1 }}
              />
              <Legend
                iconType="circle"
                iconSize={8}
                wrapperStyle={{ fontSize: 12, paddingTop: 12 }}
              />
              <Line
                type="monotone"
                dataKey="premium"
                name="Premium"
                stroke="var(--primary)"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="mass"
                name="Mass"
                stroke="#06b6d4"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="vip"
                name="VIP"
                stroke="#10b981"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Heatmap */}
        <div className="bg-card rounded-xl p-6 shadow-custom border border-border" style={{ width: 420, minWidth: 420 }}>
          <div className="mb-4">
            <h2 className="text-sm font-semibold text-foreground">Тепловая карта — активность по MCC</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Индекс отклика (0–5)</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse" style={{ tableLayout: `fixed` }}>
              <thead>
                <tr>
                  <th className="text-left text-muted-foreground font-normal pb-2 pr-2" style={{ width: 72 }}>Сегмент</th>
                  {mccCategories.map((cat) => (
                    <th key={cat} className="text-center font-normal pb-2 px-0.5" style={{ writingMode: `vertical-rl`, transform: `rotate(180deg)`, height: 64, fontSize: 10, color: `var(--muted-foreground)` }}>
                      {cat}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {segments.map((seg, si) => (
                  <tr key={seg}>
                    <td className="text-muted-foreground pr-2 py-1 text-xs font-medium">{seg}</td>
                    {mccCategories.map((_, ci) => (
                      <td key={ci} className="py-1 px-0.5">
                        <div
                          className={`heat-cell-${heatData[si][ci]} rounded`}
                          style={{ width: 28, height: 22, display: `flex`, alignItems: `center`, justifyContent: `center`, fontSize: 10, fontWeight: 600, margin: `0 auto` }}
                        >
                          {heatData[si][ci]}
                        </div>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {/* Legend */}
          <div className="flex items-center gap-2 mt-3">
            <span className="text-xs text-muted-foreground">Низкий</span>
            {[0,1,2,3,4,5].map((v) => (
              <div key={v} className={`heat-cell-${v} rounded`} style={{ width: 18, height: 18 }} />
            ))}
            <span className="text-xs text-muted-foreground">Высокий</span>
          </div>
        </div>
      </div>

      {/* Top-5 Table */}
      <div className="bg-card rounded-xl shadow-custom border border-border overflow-hidden">
        <div className="px-6 py-4 border-b border-border flex items-center justify-between">
          <h2 className="text-sm font-semibold text-foreground">Топ-5 кампаний по ROI</h2>
          <span className="text-xs text-muted-foreground">Текущий период</span>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted">
              <th className="text-left px-6 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">#</th>
              <th className="text-left px-6 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Кампания</th>
              <th className="text-right px-6 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">ROI %</th>
              <th className="text-right px-6 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Бюджет</th>
              <th className="text-right px-6 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">CTR</th>
              <th className="text-right px-6 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Статус</th>
            </tr>
          </thead>
          <tbody>
            {topCampaigns.map((c, i) => (
              <tr key={c.name} className="border-b border-border last:border-0 hover:bg-muted/50 transition-colors">
                <td className="px-6 py-3.5 text-muted-foreground font-medium">{i + 1}</td>
                <td className="px-6 py-3.5 font-medium text-foreground">{c.name}</td>
                <td className="px-6 py-3.5 text-right font-bold" style={{ color: `var(--primary)` }}>{c.roi}%</td>
                <td className="px-6 py-3.5 text-right text-foreground">{c.budget}</td>
                <td className="px-6 py-3.5 text-right text-foreground">{c.ctr}</td>
                <td className="px-6 py-3.5 text-right">
                  <span
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold"
                    style={{
                      background: `${statusColor[c.status]}20`,
                      color: statusColor[c.status],
                    }}
                  >
                    <span className="w-1.5 h-1.5 rounded-full" style={{ background: statusColor[c.status] }} />
                    {c.status === `active` ? `Активна` : `Пауза`}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
