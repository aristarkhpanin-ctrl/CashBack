# API — модель данных, контракт, бизнес-правила

Контракт спроектирован по поведению прототипа. Имена полей соответствуют `design/data.js` — фронтенд можно переносить без маппинга.

## Сущности

### User
```
id: int | uuid
name: string            // "Аристарх Панин"
email: string
role: "admin" | "marketer" | "analyst"
avatar: string          // инициалы, генерируются из имени
lastLogin: datetime | null
```

### RolePermissions
```
role: string (PK)
permissions: {
  dashboard, campaigns_view, campaigns_create,
  campaigns_edit, campaigns_delete, analytics, users: boolean
}
```
Дефолты — см. README (матрица RBAC). Права admin неизменяемы (сервер отклоняет PATCH).

### Segment (справочник)
```
id: "premium" | "mass" | "young" | "senior" | "business"
name: string            // Премиум, Массовый, Молодежь, Средний класс, Бизнес
count: int              // размер аудитории: 124500, 892000, 340000, 210000, 87000
```

### MccCategory (справочник)
```
code: string   // "5411"
name: string   // "Супермаркеты"
icon: string   // имя иконки (в прототипе emoji — заменить)
```
Набор: 5411 Супермаркеты, 5912 Аптеки, 5541 АЗС, 5812 Рестораны, 5999 Прочая розница, 7011 Отели, 4111 Транспорт, 5045 Электроника, 5600 Одежда, 7832 Кинотеатры, 5251 DIY, 5122 Косметика.

### Campaign
```
id, name: string
status: "draft" | "active" | "paused" | "completed"
startDate, endDate: date
cashbackRate: float     // %, 1–30, шаг 0.5
budget: int             // ₽
spent: int              // ₽, вычисляется из транзакций
dailyLimit: int         // ₽/день
segments: SegmentId[]
categories: MccCode[]
minTxAmount: int        // ₽ (в визарде задаётся per-категория minTxAmounts{code:int};
                        // в списке хранится минимум — при реализации лучше хранить per-категорию)
rfmMin, rfmMax: int     // 1–5 квантили
autoPause: boolean
reach: int              // = sum(count выбранных сегментов), пересчитывается
ctr: float              // %, вычисляется
roi: float              // ×, вычисляется
createdBy: userId
```

### MlLimit (per сегмент; прототип хранит в localStorage `ml_limits`, `ml_global_enabled`)
```
segmentId: PK
minCashback, maxCashback: float  // 1–30, min < max (валидация 400)
dailyBudget: int
autoApprove: boolean
riskLevel: "low" | "medium" | "high"
```
Дефолты: premium 3–15% 200К medium autoApprove✓; business 3–12% 150К medium ✓; young 2–10% 100К high ✗; mass 1–7% 80К low ✗; senior 2–8% 60К low ✓. Плюс глобальный флаг `mlGlobalEnabled: boolean`.

### Recommendation + SHAP (read-only с ML-сервиса)
```
customerId
title: string           // "Кэшбэк 7% на Аптеки"
rationale: string
baseValue: float        // базовая вероятность модели (~0.18)
prediction: float       // итоговая вероятность принятия 0–1
confidence: float
expectedROI: float
altRecs: string[]       // альтернативы, ранжированы по score
shap: [{ feature, value: string, shap: float, desc: string }]
```
Инвариант: baseValue + Σshap ≈ prediction. Customer: id, name, segment, age, city, ltv, tenure, avatar.

## REST-эндпоинты

Auth:
- `POST /auth/login` → token; `GET /auth/me` → User + permissions роли.

Справочники:
- `GET /segments`, `GET /mcc-categories`.

Пользователи (право `users`):
- `GET /users?search=&role=`, `POST /users`, `PATCH /users/:id` (в т.ч. role; свою роль менять нельзя), `DELETE /users/:id` (себя нельзя).
- `GET /roles/permissions`, `PATCH /roles/:role/permissions` (admin-роль — 403).

Кампании:
- `GET /campaigns?status=&search=`
- `POST /campaigns` (право `campaigns_create`) — сервер ставит spent=0, ctr=0, roi=0, reach из сегментов.
- `PATCH /campaigns/:id` (право `campaigns_edit`)
- `PATCH /campaigns/:id/status` — допустимые переходы: draft→active; active↔paused; active|paused→completed.
- `DELETE /campaigns/:id` (право `campaigns_delete`, только admin).

Аналитика (общие query-параметры: `campaignId?`, `period=7d|30d|90d`, `segmentId?`):
- `GET /analytics/kpis` → { campaignsCount, reach, spent, budget, avgCtr, trends{} }
- `GET /analytics/trend` → [{ date, premium, mass, young }] — принятые предложения по дням.
- `GET /analytics/funnel` → [{ stage, value, pending }] — 6 стадий.
- `GET /analytics/matrix` → { segments[], categories[], values[][], activeSegments[], activeCategories[] }
- `GET /analytics/channels` → [{ channel, sent, opened, converted, pending }]

ML:
- `GET /ml/customers` → список клиентов с prediction для левой панели.
- `GET /ml/recommendations/:customerId` → Recommendation + SHAP.
- `GET /ml/limits`, `PUT /ml/limits` (admin | analyst) — массив MlLimit + `globalEnabled`.

## Бизнес-правила и формулы

**Статус «нет данных»**: кампания считается без данных, пока `spent == 0 && ctr == 0` (реально: нет транзакций). Тогда:
- KPI «Приняли/Транзакции/Кэшбэк» → null (фронт рисует «—» и «нет данных»);
- воронка: стадии 1–2 (аудитория, отправлено ≈ 80% аудитории) заполнены, стадии 3–6 `pending: true`;
- каналы: sent > 0, opened/converted pending;
- матрица по этой кампании — «—»;
- жёлтый баннер «Данные ещё собираются…».

**Воронка** (базовые доли от аудитории, ориентиры прототипа): получили 80% → открыли 48% → приняли 18.3% → транзакция 11% → кэшбэк 10.2%. Сегментный коэффициент качества конверсии (применяется к стадиям после доставки): premium 1.28, business 1.18, young 1.05, mass 0.95, senior 0.78. Реальный бекенд считает из событий: offer_sent, offer_opened, offer_accepted, transaction, cashback_paid.

**KPI Дашборда**: выборка = активные+приостановленные (или выбранная кампания). reach = Σreach, spent = Σspent, ctr = среднее. «Выдано кэшбэка» ≈ клиенты_стадии_6 × средний_чек_кэшбэка (в прототипе ₽46).

**Матрица активности (единая для Дашборда и Аналитики)** — порт `computeActivityMatrix(campaign, period)` из `design/data.js`:
- базовые значения отклика % — таблица `MATRIX_DATA` (7 категорий × 5 сегментов);
- при выбранной кампании ячейки, где сегмент ∈ campaign.segments И категория ∈ campaign.categories, получают буст ×1.15; остальные без штрафа;
- кламп 0–99, метрика «Конверсия» = отклик × 0.65.
В production данные приходят из агрегата транзакций, но контракт ответа тот же; главное требование — Дашборд и Аналитика бьют в один эндпоинт (одинаковые цифры).

**Периоды**: в прототипе смоделированы множителями (KPI: 7d×0.23, 30d×1, 90d×2.8; зрелость отклика матрицы: 7d×0.62, 30d×1.0, 90d×1.12). В production — честная агрегация по date range; множители нужны только если делаете демо-сид.

**Каналы**: микс отправки по сегментам (Push/SMS/Email/App): premium .20/.10/.45/.25; business .18/.12/.50/.20; young .45/.08/.15/.32; mass .38/.30/.20/.12; senior .20/.55/.18/.07; all .36/.26/.22/.16. Базовые open-rate: Push .44, SMS .35, Email .30, App .67; conv-rate от открывших: .338/.402/.333/.40.

**Визард**: валидация шагов (см. SCREENS); предпросмотр охвата = Σcount выбранных сегментов; предупреждение бюджета: `dailyLimit × days(start→end) > budget`.

**ML-лимиты**: minCashback < maxCashback (шаг 0.5); сохранение атомарное («Сохранить» применяет весь набор); `globalEnabled=false` — ML-предложения приостановлены (рекомендательный сервис должен это уважать).

**Сид демо-данных** — 5 кампаний из `design/data.js` (Летний кэшбэк — Супермаркеты; Аптечный кэшбэк — Премиум; АЗС — Молодежь и Массовый; Рестораны выходного дня; Электроника — Бизнес), 6 пользователей, 5 клиентов ML с полными SHAP-наборами — использовать как fixtures.
